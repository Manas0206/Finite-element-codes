function [Dmat] = get_mat_tensor(MATERIAL,PARAMS)

Dmat = MATERIAL.kappa;

end